# Garment Business Manager — iPhone install kit

This kit contains:
- `GarmentBusinessManager_iPhone_V1.zip`: the app source project
- `codemagic.yaml`: a starter cloud build workflow

## First build (compile check)
1. Create a PRIVATE GitHub repository named `GarmentBusinessManager`.
2. In that repository, upload BOTH files from this kit:
   - `GarmentBusinessManager_iPhone_V1.zip`
   - `codemagic.yaml`
   The YAML file must be at the repository root (top level).
3. In Codemagic, connect GitHub and add this repository as a Native iOS app.
4. Select the branch containing the files and start the `garment-ios-build` workflow.
5. This first workflow compiles an unsigned `.app` to verify the source builds. It does NOT create an installable IPA.

## To install on a real iPhone
An iOS app must be signed. The next step is to configure Apple signing in Codemagic. The easiest general route for private beta testing is:
1. Enroll in the Apple Developer Program (paid membership; current price and local tax are shown by Apple during enrollment).
2. Create the app's App Store Connect record using bundle ID `com.garmentbusiness.manager`.
3. Create an App Store Connect API key and connect it to Codemagic as an App Store Connect integration.
4. Configure Codemagic iOS code signing for App Store distribution and upload the build to TestFlight.
5. Install Apple's TestFlight app on your iPhone, accept the invitation, and install Garment Manager from TestFlight.

Apple Developer Program membership is generally required for TestFlight distribution. Apple says a paid membership is not required merely to install a personal app through Xcode on a device, but that route needs Xcode on a Mac. Since you do not have a Mac, TestFlight via a hosted build service is the practical route.

## Security
- Never share your Apple password, verification code, private signing key, or App Store Connect API private key in chat.
- Do not add real customer records to the source repository.
- The app's cloud database is not connected yet. Supabase setup, authentication, access controls, and reliable sync need to be completed before using real business data.
